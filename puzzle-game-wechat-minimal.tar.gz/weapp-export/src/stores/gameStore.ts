import { create } from 'zustand'
import Taro from '@tarojs/taro'
import { Network } from '@/network'

// 拼图碎片类型
export interface PuzzlePiece {
  id: number                    // 碎片唯一ID
  correctIndex: number           // 正确位置索引
  currentIndex: number           // 当前位置索引
  x: number                      // 当前X坐标
  y: number                      // 当前Y坐标
  imageSrc: string               // 碎片图片（canvas切割后的临时路径）
}

// 关卡配置
interface LevelConfig {
  level: number                  // 关卡编号
  gridSize: number               // 网格大小（8×8、10×10、12×12）
  imageUrl: string               // 原图URL
  originalUrl?: string           // 原始网络图片URL（用于下载原图）
}

// 游戏状态
interface GameState {
  // 游戏基本信息
  currentLevel: number           // 当前关卡
  gridSize: number               // 当前网格大小
  imageUrl: string               // 当前图片URL（本地路径或base64，用于显示）
  originalImageUrl: string       // 原始图片URL（网络地址，用于下载）
  isPlaying: boolean             // 是否正在游戏
  isComplete: boolean            // 是否完成拼图
  isFailed: boolean              // 是否失败
  isLoading: boolean             // 是否加载中
  isGameCompleted: boolean       // 是否通关（完成所有关卡）
  isFreePlayMode: boolean        // 是否是自由游玩模式（不倒计时）

  // 图片资源
  imageList: string[]            // 图片列表（预加载的100张图片URL）
  imagePaths: string[]           // 图片本地路径列表（缓存后的本地路径）
  imagesLoaded: number           // 已加载的图片数量
  isImagesLoading: boolean       // 是否正在加载图片
  isImagesPreloaded: boolean     // 图片是否已预加载并缓存
  levelImageMap: Record<number, { url: string; path: string }>  // 每一关的图片映射（包含URL和本地路径）
  imageVersion: string           // 图片版本号（用于支持增量更新）

  // 网络状态
  networkType: string            // 网络类型（wifi/4g/3g/2g/none）
  isOnline: boolean              // 是否在线
  isNetworkMonitoring: boolean   // 是否正在监听网络状态

  // 计时相关
  startTime: number              // 开始时间戳
  countdownTime: number          // 倒计时剩余时间（秒）
  initialCountdownTime: number   // 初始倒计时时长（秒）
  isTimeFrozen: boolean          // 是否时间冻结
  freezeTimeRemaining: number    // 时间冻结剩余时间（秒）
  totalTimeSpent: number         // 总花费时间（秒），从第1关开始累计
  levelStartTime: number         // 当前关卡开始时间戳

  // 拼图数据
  pieces: PuzzlePiece[]          // 拼图碎片数组
  selectedPiece: PuzzlePiece | null  // 当前选中的碎片

  // 功能状态
  showHint: boolean              // 是否显示提示
  showOriginalImage: boolean     // 是否显示原图
  originalImageTimeRemaining: number  // 查看原图剩余时间（秒）
  isCountdownPaused: boolean     // 游戏倒计时是否暂停（查看原图时暂停）

  // 使用次数限制
  hintCount: number              // 提示使用次数（最多3次）
  originalImageCount: number     // 原图查看次数（最多3次）
  freezeCount: number            // 冻结时间使用次数（最多1次）

  // 动作方法
  preloadImages: () => Promise<void>
  startGame: (level: number, isFreePlay?: boolean) => Promise<void>
  resetGame: () => void
  restartGame: () => Promise<void>  // 重新开始游戏（重新加载图片）
  selectPiece: (piece: PuzzlePiece) => void
  movePiece: (piece: PuzzlePiece, targetX: number, targetY: number) => void
  updatePieceIndex: (pieceId: number, newIndex: number) => void
  swapPieces: (piece1: PuzzlePiece, piece2: PuzzlePiece) => void
  toggleHint: () => void
  toggleOriginalImage: () => void
  updateCountdown: () => void
  updateFreezeCountdown: () => void
  updateOriginalImageCountdown: () => void
  freezeTime: () => void
  checkComplete: () => boolean
  checkFailed: () => boolean
  loadNextLevel: () => Promise<void>
  startFreePlayMode: (level: number, gridSize?: number) => Promise<void>  // 自由游玩模式（不倒计时）

  // 网络状态管理
  initNetworkMonitoring: () => void  // 初始化网络状态监听
  stopNetworkMonitoring: () => void  // 停止网络状态监听
  clearCache: () => Promise<void>    // 清除图片缓存
}

// 关卡难度配置
const LEVEL_DIFFICULTY_CONFIG = [
  { minLevel: 1, maxLevel: 3, gridSize: 3, label: '入门' },
  { minLevel: 4, maxLevel: 6, gridSize: 4, label: '进阶' },
  { minLevel: 7, maxLevel: 9, gridSize: 5, label: '挑战' },
  { minLevel: 10, maxLevel: 12, gridSize: 6, label: '大师' },
  { minLevel: 13, maxLevel: Infinity, gridSize: 7, label: '无限' }
]

// 关卡配置生成器
function getLevelConfig(level: number, imageList: string[], levelImageMap: Record<number, { url: string; path: string }>): LevelConfig {
  // 根据关卡查找对应的难度配置
  const difficulty = LEVEL_DIFFICULTY_CONFIG.find(
    config => level >= config.minLevel && level <= config.maxLevel
  ) || LEVEL_DIFFICULTY_CONFIG[LEVEL_DIFFICULTY_CONFIG.length - 1]  // 默认使用最高难度

  const gridSize = difficulty.gridSize

  // 使用预先规划的每一关的图片映射（优先使用本地路径）
  let imageUrl: string
  let originalUrl: string  // 原始网络图片URL（用于下载）

  if (levelImageMap[level]) {
    // 优先使用本地路径（已缓存，加载更快）
    imageUrl = levelImageMap[level].path
    originalUrl = levelImageMap[level].url  // 保存原始URL
    console.log(`🖼️  关卡 ${level} 使用本地路径:`, imageUrl)
  } else {
    // 降级逻辑：使用预加载的图片列表
    imageUrl = imageList.length > 0
      ? imageList[(level - 1) % imageList.length]
      : 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1080&h=1440&fit=crop&q=80' // 默认图片
    originalUrl = imageUrl  // 网络图片，直接使用
    console.log(`🖼️  关卡 ${level} 使用动态计算的图片（降级逻辑）`)
  }

  return {
    level,
    gridSize,
    imageUrl,
    originalUrl
  }
}

// 初始化时从本地存储读取缓存数据
const initializeFromStorage = () => {
  try {
    const cachedLevelImageMap = Taro.getStorageSync('levelImageMap') || {}
    const cachedImageList = Taro.getStorageSync('imageList') || []
    const cachedImageVersion = Taro.getStorageSync('imageVersion') || ''
    const cachedIsImagesPreloaded = cachedImageList.length > 0 && Object.keys(cachedLevelImageMap).length > 0
    
    // 读取游戏进度
    const cachedGameProgress = Taro.getStorageSync('gameProgress') || {}
    const savedCurrentLevel = cachedGameProgress.currentLevel || 1

    console.log('📦 从本地存储初始化游戏状态:')
    console.log('- levelImageMap length:', Object.keys(cachedLevelImageMap).length)
    console.log('- imageList length:', cachedImageList.length)
    console.log('- imageVersion:', cachedImageVersion)
    console.log('- isImagesPreloaded:', cachedIsImagesPreloaded)
    console.log('- savedCurrentLevel:', savedCurrentLevel)

    return {
      levelImageMap: cachedLevelImageMap,
      imageList: cachedImageList,
      imageVersion: cachedImageVersion,
      isImagesPreloaded: cachedIsImagesPreloaded,
      imagesLoaded: cachedImageList.length,
      currentLevel: savedCurrentLevel
    }
  } catch (error) {
    console.error('❌ 从本地存储初始化失败:', error)
    return {}
  }
}

const initialStorageData = initializeFromStorage()

// 创建游戏store
export const useGameStore = create<GameState>((set, get) => ({
  // 初始状态
  currentLevel: 1,
  gridSize: 3,
  imageUrl: '',
  originalImageUrl: '',  // 原始图片URL（用于下载）
  isPlaying: false,
  isComplete: false,
  isFailed: false,
  isLoading: false,
  isGameCompleted: false,
  isFreePlayMode: false,
  imageList: initialStorageData.imageList || [],
  imagePaths: [],
  imagesLoaded: initialStorageData.imagesLoaded || 0,
  isImagesLoading: false,
  isImagesPreloaded: initialStorageData.isImagesPreloaded || false,
  levelImageMap: initialStorageData.levelImageMap || {},  // 每一关的图片映射
  imageVersion: initialStorageData.imageVersion || '',  // 图片版本号
  networkType: '',  // 网络类型
  isOnline: true,  // 是否在线（默认在线）
  isNetworkMonitoring: false,  // 是否正在监听网络状态
  startTime: 0,
  countdownTime: 180,
  initialCountdownTime: 180,
  isTimeFrozen: false,
  freezeTimeRemaining: 0,
  totalTimeSpent: 0,
  levelStartTime: 0,
  pieces: [],
  selectedPiece: null,
  showHint: false,
  showOriginalImage: false,
  originalImageTimeRemaining: 0,
  isCountdownPaused: false,
  hintCount: 0,
  originalImageCount: 0,
  freezeCount: 0,

  // 预加载图片（使用 Taro.getImageInfo 真正缓存图片，支持版本号管理和离线模式）
  preloadImages: async () => {
    set({ isImagesLoading: true, imagesLoaded: 0, imageList: [], isImagesPreloaded: false })

    try {
      // 检测网络状态
      const networkType = await Taro.getNetworkType()
      const isOffline = networkType.networkType === 'none'

      if (isOffline) {
        console.log('📶 网络离线，尝试使用本地缓存的图片')

        // 尝试从本地存储加载缓存的图片
        const cachedLevelImageMap = Taro.getStorageSync('levelImageMap') || {}
        const cachedImageList = Taro.getStorageSync('imageList') || []

        if (Object.keys(cachedLevelImageMap).length > 0 && cachedImageList.length > 0) {
          console.log(`✅ 从本地缓存加载了 ${Object.keys(cachedLevelImageMap).length} 张图片`)

          set({
            imageList: cachedImageList,
            imagePaths: cachedImageList, // 离线模式下使用缓存路径
            imagesLoaded: cachedImageList.length,
            isImagesLoading: false,
            isImagesPreloaded: true,
            levelImageMap: cachedLevelImageMap,
            imageVersion: Taro.getStorageSync('imageVersion') || ''
          })

          Taro.showToast({ title: '离线模式：使用缓存的图片', icon: 'none', duration: 2000 })
          return
        } else {
          console.log('⚠️  没有本地缓存，无法离线使用')
          Taro.showToast({ title: '离线模式：请先联网下载图片', icon: 'none', duration: 3000 })
          set({
            isImagesLoading: false,
            isImagesPreloaded: false
          })
          return
        }
      }

      // 在线模式：从服务器获取随机图片列表
      console.log('🖼️  从服务器获取图片列表...')
      const response = await Network.request({
        url: '/api/images/random',
        method: 'GET'
      })

      if (response.data?.data?.images) {
        const serverImages = response.data.data.images
        const serverVersion = response.data.data.version || '' // 获取服务器版本号
        console.log(`✅ 从服务器获取到 ${serverImages.length} 张图片，版本号: ${serverVersion}`)

        // 检查版本号是否变化
        const localVersion = Taro.getStorageSync('imageVersion') || ''
        const versionChanged = serverVersion && localVersion && serverVersion !== localVersion

        if (versionChanged) {
          console.log(`🔄 图片版本号已更新: ${localVersion} -> ${serverVersion}，将重新加载图片`)
          // 清除本地缓存
          Taro.removeStorageSync('levelImageMap')
          Taro.removeStorageSync('imageList')
        }

        const loadedImages: string[] = []
        const loadedPaths: string[] = []  // 新增：保存本地路径
        let loadedCount = 0

        // 分批大小：每次加载 10 张图片
        const BATCH_SIZE = 10

        // 使用 Taro.getImageInfo 预加载每张图片（真正缓存到本地）
        // 添加重试机制，最多重试 3 次
        const loadImagePromise = async (url: string, index: number): Promise<void> => {
          const maxRetries = 3
          let retryCount = 0

          const tryLoadImage = async (): Promise<void> => {
            try {
              console.log(`📥 正在加载图片 ${index + 1}/${serverImages.length} ${retryCount > 0 ? `(重试 ${retryCount}/${maxRetries})` : ''}: ${url.substring(0, 50)}...`)

              // 使用 Taro.getImageInfo 下载并缓存图片，并获取本地路径
              const res = await Taro.getImageInfo({
                src: url
              })

              // 保存原始 URL 和本地路径
              loadedImages[index] = url
              loadedPaths[index] = res.path  // 保存本地路径
              loadedCount++
              set({ imagesLoaded: loadedCount })
              console.log(`✅ 图片 ${index + 1} 加载完成，本地路径:`, res.path)
            } catch (error) {
              retryCount++
              if (retryCount <= maxRetries) {
                console.log(`🔄 图片 ${index + 1} 加载失败，正在重试 ${retryCount}/${maxRetries}...`)
                // 延迟后重试（指数退避：1s, 2s, 4s）
                await new Promise(resolve => setTimeout(resolve, Math.pow(2, retryCount - 1) * 1000))
                return tryLoadImage()
              } else {
                console.error(`❌ 图片 ${index + 1} 加载失败，已重试 ${maxRetries} 次，跳过:`, error)
                // 加载失败也继续，使用原始 URL
                loadedImages[index] = url
                loadedPaths[index] = url  // 降级使用 URL
                loadedCount++
                set({ imagesLoaded: loadedCount })
              }
            }
          }

          await tryLoadImage()
        }

        // 分批加载所有图片（每次 BATCH_SIZE 张）
        for (let i = 0; i < serverImages.length; i += BATCH_SIZE) {
          const batch = serverImages.slice(i, i + BATCH_SIZE)
          const batchStartIndex = i

          console.log(`📦 加载批次 ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(serverImages.length / BATCH_SIZE)}，共 ${batch.length} 张图片`)

          await Promise.all(
            batch.map((url, batchIndex) => loadImagePromise(url, batchStartIndex + batchIndex))
          )

          // 每批加载后短暂延迟，避免网络拥塞
          if (i + BATCH_SIZE < serverImages.length) {
            await new Promise(resolve => setTimeout(resolve, 100))
          }
        }

        console.log(`✅ 所有图片加载完成，成功 ${loadedCount}/${serverImages.length}`)

        // 预先规划每一关用哪张图片（包含URL和本地路径）
        // 前100关使用前100张图片，如果图片不够则循环使用
        const levelImageMap: Record<number, { url: string; path: string }> = {}
        for (let i = 0; i < 100; i++) {
          const imageIndex = i % loadedImages.length
          levelImageMap[i + 1] = {
            url: loadedImages[imageIndex],
            path: loadedPaths[imageIndex]
          }
          console.log(`📋 关卡 ${i + 1} 使用图片 ${imageIndex + 1}:`, {
            url: loadedImages[imageIndex].substring(0, 50),
            path: loadedPaths[imageIndex],
            pathType: loadedPaths[imageIndex].startsWith('wxfile://') ? '本地路径' : '网络路径'
          })
        }

        console.log('✅ levelImageMap 已生成，长度:', Object.keys(levelImageMap).length)
        console.log('✅ 第一关图片路径:', levelImageMap[1]?.path)

        // 保存版本号到本地
        if (serverVersion) {
          Taro.setStorageSync('imageVersion', serverVersion)
          console.log('💾 保存图片版本号到本地:', serverVersion)
        }

        // 保存图片到本地缓存（用于离线模式）
        Taro.setStorageSync('levelImageMap', levelImageMap)
        Taro.setStorageSync('imageList', loadedImages)
        console.log('💾 保存图片到本地缓存，支持离线模式')

        set({
          imageList: loadedImages,
          imagePaths: loadedPaths,  // 保存本地路径列表
          imagesLoaded: serverImages.length,
          isImagesLoading: false,
          isImagesPreloaded: true,  // 标记图片已预加载完成
          levelImageMap,  // 保存每一关的图片映射
          imageVersion: serverVersion  // 保存版本号到状态
        })
      } else {
        throw new Error('服务器返回数据格式错误')
      }
    } catch (error) {
      console.error('❌ 获取图片列表失败:', error)
      // 失败时使用默认图片
      set({
        imageList: [],
        imagesLoaded: 0,
        isImagesLoading: false,
        isImagesPreloaded: false
      })
    }
  },

  // 开始游戏
  startGame: async (level: number, isFreePlay: boolean = false) => {
    const { imageList, levelImageMap } = get()
    const isWeapp = Taro.getEnv() === Taro.ENV_TYPE.WEAPP

    const config = getLevelConfig(level, imageList, levelImageMap)

    console.log('==========================================')
    console.log('🎮 startGame 被调用，关卡:', level, '模式:', isFreePlay ? '自由模式' : '正常模式')
    console.log('📋 imageList 长度:', imageList.length)
    console.log('📋 levelImageMap 长度:', Object.keys(levelImageMap).length)
    console.log('📋 当前平台:', isWeapp ? '小程序' : 'H5')

    console.log('🎮 开始游戏，关卡:', config.level)
    console.log('🖼️  图片 URL:', config.imageUrl.substring(0, 80))
    console.log('🖼️  图片 URL 长度:', config.imageUrl.length)
    console.log('🖼️  图片 URL 类型:',
      config.imageUrl.startsWith('data:image') ? 'Base64' :
      config.imageUrl.startsWith('wxfile://') ? '本地路径' : '网络路径'
    )

    // 直接使用 getLevelConfig 返回的图片路径
    // 小程序端使用本地路径（wxfile://），H5 端使用 Base64 或网络路径
    const finalImageUrl = config.imageUrl

    console.log('🖼️  最终图片 URL:', finalImageUrl.substring(0, 80))
    console.log('==========================================')

    // 根据关卡设置不同的倒计时时长
    let countdownTime = 180
    if (config.level >= 1 && config.level <= 3) {
      countdownTime = 30  // 第1-3关：30秒
    } else if (config.level >= 4 && config.level <= 6) {
      countdownTime = 60  // 第4-6关：60秒
    } else if (config.level >= 7 && config.level <= 9) {
      countdownTime = 90  // 第7-9关：90秒
    } else {
      countdownTime = 180  // 第10关：180秒
    }

    console.log(`⏱️  关卡 ${config.level} 倒计时：${countdownTime}秒`)

    set({
      currentLevel: config.level,
      gridSize: config.gridSize,
      imageUrl: finalImageUrl,  // 使用本地路径或 Base64
      originalImageUrl: config.originalUrl,  // 保存原始URL用于下载
      isPlaying: true,
      isComplete: false,
      isFailed: false,
      isLoading: true,
      isFreePlayMode: isFreePlay,  // 根据参数设置游戏模式
      startTime: Date.now(),
      countdownTime,
      initialCountdownTime: countdownTime,  // 保存初始倒计时时长
      isTimeFrozen: false,
      freezeTimeRemaining: 0,
      selectedPiece: null,
      showHint: false,
      showOriginalImage: false,
      hintCount: 0,
      originalImageCount: 0,
      freezeCount: 0,
      levelStartTime: Date.now()  // 记录当前关卡开始时间
    })

    // 生成拼图碎片
    await generatePieces(config.gridSize, finalImageUrl)

    set({ isLoading: false })
  },

  // 重置游戏
  resetGame: () => {
    const { currentLevel } = get()
    get().startGame(currentLevel)
  },

  // 选中碎片
  selectPiece: (piece: PuzzlePiece) => {
    set({ selectedPiece: piece })
  },

  // 移动碎片
  movePiece: (piece: PuzzlePiece, targetX: number, targetY: number) => {
    set(state => ({
      pieces: state.pieces.map(p =>
        p.id === piece.id
          ? { ...p, x: targetX, y: targetY }
          : p
      )
    }))
  },

  // 更新碎片索引
  updatePieceIndex: (pieceId: number, newIndex: number) => {
    set(state => ({
      pieces: state.pieces.map(p =>
        p.id === pieceId
          ? { ...p, currentIndex: newIndex }
          : p
      )
    }))
  },

  // 交换碎片位置
  swapPieces: (piece1: PuzzlePiece, piece2: PuzzlePiece) => {
    set(state => {
      const newPieces = [...state.pieces]
      const piece1Index = newPieces.findIndex(p => p.id === piece1.id)
      const piece2Index = newPieces.findIndex(p => p.id === piece2.id)

      console.log('swapPieces - 交换前：', {
        piece1: { id: piece1.id, currentIndex: newPieces[piece1Index].currentIndex, x: newPieces[piece1Index].x, y: newPieces[piece1Index].y },
        piece2: { id: piece2.id, currentIndex: newPieces[piece2Index].currentIndex, x: newPieces[piece2Index].x, y: newPieces[piece2Index].y }
      })

      // 交换当前位置索引
      const tempCurrentIndex = newPieces[piece1Index].currentIndex
      newPieces[piece1Index].currentIndex = newPieces[piece2Index].currentIndex
      newPieces[piece2Index].currentIndex = tempCurrentIndex

      // 计算新的格子坐标（精确吸附）
      const gridSize = Math.sqrt(newPieces.length)
      const pieceSize = 100 / gridSize

      // 更新 piece1 的坐标（吸附到它的新格子位置）
      const piece1NewRow = Math.floor(newPieces[piece1Index].currentIndex / gridSize)
      const piece1NewCol = newPieces[piece1Index].currentIndex % gridSize
      newPieces[piece1Index].x = Math.round(piece1NewCol * pieceSize * 100) / 100  // 保留2位小数
      newPieces[piece1Index].y = Math.round(piece1NewRow * pieceSize * 100) / 100  // 保留2位小数

      // 更新 piece2 的坐标（吸附到它的新格子位置）
      const piece2NewRow = Math.floor(newPieces[piece2Index].currentIndex / gridSize)
      const piece2NewCol = newPieces[piece2Index].currentIndex % gridSize
      newPieces[piece2Index].x = Math.round(piece2NewCol * pieceSize * 100) / 100  // 保留2位小数
      newPieces[piece2Index].y = Math.round(piece2NewRow * pieceSize * 100) / 100  // 保留2位小数

      console.log('swapPieces - 交换后：', {
        piece1: { id: piece1.id, currentIndex: newPieces[piece1Index].currentIndex, x: newPieces[piece1Index].x, y: newPieces[piece1Index].y },
        piece2: { id: piece2.id, currentIndex: newPieces[piece2Index].currentIndex, x: newPieces[piece2Index].x, y: newPieces[piece2Index].y }
      })

      return { pieces: newPieces }
    })
  },

  // 切换提示显示
  toggleHint: () => {
    set(state => {
      // 如果当前显示提示，则关闭
      if (state.showHint) {
        return { showHint: false }
      }
      // 如果未显示提示，检查使用次数
      if (state.hintCount >= 3) {
        return { showHint: false }
      }
      // 增加使用次数并显示提示
      return { showHint: true, hintCount: state.hintCount + 1 }
    })
  },

  // 切换原图显示
  toggleOriginalImage: () => {
    set(state => {
      // 如果当前显示原图，则关闭
      if (state.showOriginalImage) {
        return { showOriginalImage: false, originalImageTimeRemaining: 0, isCountdownPaused: false }
      }
      // 如果未显示原图，检查使用次数
      if (state.originalImageCount >= 3) {
        return { showOriginalImage: false }
      }
      // 增加使用次数并显示原图，设置5秒倒计时，暂停游戏倒计时
      return {
        showOriginalImage: true,
        originalImageCount: state.originalImageCount + 1,
        originalImageTimeRemaining: 5,
        isCountdownPaused: true
      }
    })
  },

  // 更新查看原图倒计时
  updateOriginalImageCountdown: () => {
    const { showOriginalImage, originalImageTimeRemaining } = get()
    if (showOriginalImage && originalImageTimeRemaining > 0) {
      const newRemaining = originalImageTimeRemaining - 1
      set({ originalImageTimeRemaining: newRemaining })
      // 查看原图时间结束，关闭原图显示并恢复游戏倒计时
      if (newRemaining <= 0) {
        set({ showOriginalImage: false, isCountdownPaused: false })
      }
    }
  },

  // 更新倒计时
  updateCountdown: () => {
    const { startTime, isPlaying, isComplete, isFailed, isTimeFrozen, isFreePlayMode, initialCountdownTime, isCountdownPaused } = get()
    // 自由游玩模式下不倒计时，查看原图时暂停倒计时，冻结时间时暂停倒计时
    if (!isFreePlayMode && isPlaying && !isComplete && !isFailed && !isTimeFrozen && !isCountdownPaused) {
      const elapsed = Math.floor((Date.now() - startTime) / 1000)
      const remaining = Math.max(0, initialCountdownTime - elapsed)
      set({ countdownTime: remaining })
    }
  },

  // 更新冻结倒计时
  updateFreezeCountdown: () => {
    const { isTimeFrozen, freezeTimeRemaining } = get()
    if (isTimeFrozen && freezeTimeRemaining > 0) {
      const newRemaining = freezeTimeRemaining - 1
      set({ freezeTimeRemaining: newRemaining })
      // 冻结时间结束，恢复倒计时
      if (newRemaining <= 0) {
        set({ isTimeFrozen: false })
      }
    }
  },

  // 冻结时间
  freezeTime: () => {
    const { isTimeFrozen, freezeTimeRemaining, freezeCount } = get()
    if (!isTimeFrozen && freezeTimeRemaining <= 0 && freezeCount < 1) {
      set({ isTimeFrozen: true, freezeTimeRemaining: 10, freezeCount: 1 })
    }
  },

  // 检查是否失败
  checkFailed: () => {
    const { countdownTime, isPlaying, isComplete } = get()
    if (isPlaying && !isComplete && countdownTime <= 0) {
      set({ isFailed: true, isPlaying: false })
      return true
    }
    return false
  },

  // 检查是否完成
  checkComplete: () => {
    const { pieces } = get()
    const isComplete = pieces.every(piece => piece.currentIndex === piece.correctIndex)
    set({ isComplete })
    return isComplete
  },

  // 进入下一关
  loadNextLevel: async () => {
    const { currentLevel, levelStartTime, totalTimeSpent } = get()

    // 计算当前关卡花费的时间（秒）
    const currentTime = Date.now()
    const timeSpentThisLevel = Math.floor((currentTime - levelStartTime) / 1000)

    // 累计到总花费时间
    const newTotalTimeSpent = totalTimeSpent + timeSpentThisLevel
    console.log(`⏱️  关卡 ${currentLevel} 花费时间: ${timeSpentThisLevel}秒，总花费时间: ${newTotalTimeSpent}秒`)

    // 更新总花费时间
    set({ totalTimeSpent: newTotalTimeSpent })

    // 保存游戏进度到本地存储
    const nextLevel = currentLevel + 1
    console.log(`💾 保存游戏进度: 当前关卡 ${currentLevel}，下一关 ${nextLevel}`)
    try {
      Taro.setStorageSync('gameProgress', {
        currentLevel: nextLevel,
        totalTimeSpent: newTotalTimeSpent,
        lastPlayTime: Date.now()
      })
      console.log('✅ 游戏进度已保存')
    } catch (error) {
      console.error('❌ 保存游戏进度失败:', error)
    }

    // 进入下一关（移除10关限制，支持无限关卡）
    await get().startGame(nextLevel)
  },

  // 自由游玩模式（不倒计时）
  startFreePlayMode: async (level: number, gridSize?: number) => {
    const { imageList, levelImageMap } = get()

    console.log('🎮 自由游玩模式，关卡:', level)

    // 自由模式：随机选择图片
    let imageUrl: string
    let originalUrl: string

    if (levelImageMap[level]) {
      // 如果有缓存的图片，随机选择一张
      imageUrl = levelImageMap[level].path
      originalUrl = levelImageMap[level].url
      console.log(`🖼️  自由模式使用缓存图片: ${level}`)
    } else {
      // 否则从 imageList 随机选择
      const randomIndex = (level * 17) % imageList.length
      imageUrl = imageList[randomIndex]
      originalUrl = imageUrl
      console.log(`🖼️  自由模式随机使用图片 ${randomIndex + 1}/${imageList.length}`)
    }

    // 如果传入了 gridSize，使用传入的值，否则使用默认的 3
    const finalGridSize = gridSize || 3

    set({
      currentLevel: level,
      gridSize: finalGridSize,
      imageUrl,
      originalImageUrl: originalUrl,  // 保存原始URL用于下载
      isPlaying: true,
      isComplete: false,
      isFailed: false,
      isLoading: true,
      isFreePlayMode: true,  // 自由游玩模式，不倒计时
      startTime: Date.now(),
      countdownTime: 9999,  // 设置一个很大的值，不真正倒计时
      initialCountdownTime: 9999,  // 初始倒计时时长
      isTimeFrozen: false,
      freezeTimeRemaining: 0,
      selectedPiece: null,
      showHint: false,
      showOriginalImage: false,
      hintCount: 0,
      originalImageCount: 0,
      freezeCount: 0,
      levelStartTime: Date.now()
    })

    // 生成拼图碎片
    await generatePieces(finalGridSize, imageUrl)

    set({ isLoading: false })
  },

  // 重新开始游戏（重新加载新图片）
  restartGame: async () => {
    console.log('🔄 重新开始游戏，重新加载图片...')

    // 清空当前游戏状态
    set({
      currentLevel: 1,
      gridSize: 3,
      imageUrl: '',
      isPlaying: false,
      isComplete: false,
      isFailed: false,
      isLoading: false,
      isGameCompleted: false,
      pieces: [],
      selectedPiece: null,
      showHint: false,
      showOriginalImage: false,
      hintCount: 0,
      originalImageCount: 0,
      freezeCount: 0,
      startTime: 0,
      countdownTime: 180,
      initialCountdownTime: 180,
      isTimeFrozen: false,
      freezeTimeRemaining: 0,
      totalTimeSpent: 0,  // 重置总花费时间
      levelStartTime: 0,  // 重置关卡开始时间
      levelImageMap: {}  // 清空关卡图片映射
    })

    // 重新加载新图片
    await get().preloadImages()

    // 开始第一关
    await get().startGame(1)
  },

  // 初始化网络状态监听
  initNetworkMonitoring: () => {
    if (get().isNetworkMonitoring) {
      console.log('⚠️  网络状态监听已存在，跳过')
      return
    }

    console.log('📶 初始化网络状态监听...')

    // 获取初始网络状态
    Taro.getNetworkType({
      success: (res) => {
        const isOnline = res.networkType !== 'none'
        console.log(`📶 初始网络状态: ${res.networkType}, 在线: ${isOnline}`)
        set({
          networkType: res.networkType,
          isOnline
        })
      },
      fail: () => {
        console.log('⚠️  获取网络状态失败，默认在线')
        set({
          networkType: 'unknown',
          isOnline: true
        })
      }
    })

    // 监听网络状态变化
    Taro.onNetworkStatusChange((res) => {
      const isOnline = res.networkType !== 'none'
      console.log(`📶 网络状态变化: ${res.networkType}, 在线: ${isOnline}`)

      set({
        networkType: res.networkType,
        isOnline
      })

      // 网络变化时自动切换模式
      if (isOnline) {
        console.log('🌐 网络已恢复，可以正常使用')
        Taro.showToast({ title: '网络已恢复', icon: 'success', duration: 1500 })
      } else {
        console.log('📵 网络已断开，切换到离线模式')
        Taro.showToast({ title: '网络已断开，使用离线模式', icon: 'none', duration: 2000 })
      }
    })

    set({ isNetworkMonitoring: true })
  },

  // 停止网络状态监听
  stopNetworkMonitoring: () => {
    if (!get().isNetworkMonitoring) {
      console.log('⚠️  网络状态监听未运行，跳过')
      return
    }

    console.log('📶 停止网络状态监听...')
    Taro.offNetworkStatusChange()
    set({ isNetworkMonitoring: false })
  },

  // 清除图片缓存
  clearCache: async () => {
    console.log('🗑️  清除图片缓存...')

    // 清除本地存储
    Taro.removeStorageSync('levelImageMap')
    Taro.removeStorageSync('imageList')
    Taro.removeStorageSync('imageVersion')

    // 重置状态
    set({
      imageList: [],
      imagePaths: [],
      imagesLoaded: 0,
      isImagesPreloaded: false,
      levelImageMap: {},
      imageVersion: ''
    })

    console.log('✅ 图片缓存已清除')

    Taro.showToast({ title: '缓存已清除', icon: 'success', duration: 1500 })
  }
}))

// 生成拼图碎片
async function generatePieces(gridSize: number, imageUrl: string): Promise<void> {
  const pieceSize = 100 / gridSize  // 每个碎片的大小（百分比）

  // 生成碎片数组
  const pieces: PuzzlePiece[] = []
  for (let row = 0; row < gridSize; row++) {
    for (let col = 0; col < gridSize; col++) {
      const correctIndex = row * gridSize + col
      pieces.push({
        id: correctIndex,
        correctIndex,
        currentIndex: correctIndex,
        x: col * pieceSize,
        y: row * pieceSize,
        imageSrc: imageUrl  // 临时使用原图，后续用canvas切割
      })
    }
  }

  // 打乱碎片位置
  const shuffledPieces = shuffleArray([...pieces])

  // 更新碎片的当前位置和坐标
  shuffledPieces.forEach((piece, index) => {
    const row = Math.floor(index / gridSize)
    const col = index % gridSize
    piece.currentIndex = index
    piece.x = col * pieceSize
    piece.y = row * pieceSize
  })

  useGameStore.setState({ pieces: shuffledPieces })
}

// 打乱数组（Fisher-Yates算法）
function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array]
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
  }
  return shuffled
}
